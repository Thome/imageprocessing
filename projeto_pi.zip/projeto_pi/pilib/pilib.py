import matplotlib, matplotlib.pyplot as plt
import numpy as np

# shape = (number of lines, length of lines) (altura, largura)

def imread(filename):
	image = plt.imread(filename)
	if (image.dtype == 'float32'): #if image is .png
		image = (np.multiply(image,255)).astype('uint8')
	return image

def nchannels(image): #3 if RBG, 1 if grayscale
	if(len(image.shape)<3):
		return 1
	elif (len(image.shape)==3):
		return 3

def size(image): #(altura, largura) => (largura, altura)
	return [image.shape[1], image.shape[0]]

def rgb2gray(image):
	return np.dot(image, [0.299, 0.587, 0.114])

def imreadgray(filename):
	image = imread(filename)
	if(nchannels(image)==3): #if rgb
		image = rgb2gray(image)
	return image

def imshow(image):
	if(nchannels(image)==1): #if grayscale
		plt.imshow(image, cmap='gray')
	else:
		plt.imshow(image)
	plt.show()

def thresh(image, threshold):
	image[image>=threshold] = 255
	image[image<threshold] = 0
	return image

def negative(image):
	return 255 - image

def contrast(f,r,m):
	return r * (f - m) + m

def hist(image):
	if(nchannels(image)==1): #if grayscale
		histo = np.zeros(256)
		for linha in image:
			for pixel in linha:
				histo[pixel] += 1
	else: #if rgb
		histo = np.zeros((256,3),dtype='uint8')
		for linha in image:
			for pixel in linha:
				for color in range(3): #1=r,2=g,3=b
					pixelcor = pixel[color]
					histo[pixelcor][color] += 1
	return histo